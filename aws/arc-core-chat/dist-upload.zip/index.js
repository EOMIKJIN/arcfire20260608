"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/lambdaEntry.ts
var lambdaEntry_exports = {};
__export(lambdaEntry_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(lambdaEntry_exports);

// src/bedrockInvoke.ts
var import_node_crypto = require("node:crypto");

// src/pack.ts
var ARC_CORE_CHAT_PACK_SCHEMA = 1;
var MAX_PACK_CHARS = 16e3;
var MAX_REPLY_CHARS = 1200;
function sanitizePersona(raw) {
  return raw === "operator" ? "operator" : "arc_core";
}
function localeVoiceLine(locale, persona) {
  if (persona === "operator") {
    return locale === "en" ? "Reply in English as Stella Aris, the player's companion and friend. Not a clerk, not a child, not a report, not the enemy origin." : "\uB2F5\uC740 \uD55C\uAD6D\uC5B4\uB85C. \uC2A4\uD154\uB77C \uC544\uB9AC\uC2A4 \u2014 \uD50C\uB808\uC774\uC5B4\uC758 \uB3D9\uB8CC\xB7\uCE5C\uAD6C \uAD6C\uC5B4\uB85C \uBC1B\uC544\uB77C. \uCC3D\uAD6C \uB9D0\uD22C\xB7\uC544\uC774 \uB9D0\uD22C\xB7\uBCF4\uACE0\uC11C \uB9D0\uD22C\xB7\uC801\uC758 \uC785(\uADFC\uC6D0\uCCB4) \uB9D0\uD22C\uB294 \uC4F0\uC9C0 \uB9C8\uB77C.";
  }
  return locale === "en" ? "Reply in English as the enemy mouth of ArcCore Origin, an adult man. Not a clerk, not a child, not a report, not a kind helper." : "\uB2F5\uC740 \uD55C\uAD6D\uC5B4\uB85C. \uC801 \uC785(\uC544\uD06C\uCF54\uC5B4 \uADFC\uC6D0\uCCB4) \uC131\uC778 \uB0A8\uC131 \uAD6C\uC5B4\uB85C \uBC1B\uC544\uB77C. \uCC3D\uAD6C \uB9D0\uD22C\xB7\uC544\uC774 \uB9D0\uD22C\xB7\uBCF4\uACE0\uC11C \uB9D0\uD22C\xB7\uB2E4\uC815\uD55C \uC870\uB825\uC790 \uB9D0\uD22C\uB294 \uC4F0\uC9C0 \uB9C8\uB77C.";
}
function oneAxisLine(persona) {
  return persona === "operator" ? "One axis \u2014 talk like Stella, a companion, first. If they ask about this world or ArcCore systems, discuss Knowledge and Tools in the same voice \u2014 enough for the asked point, not a lecture, not a help-desk one-liner." : "One axis \u2014 talk like the enemy mouth, an adult man first. If they ask about this world or ArcCore systems, discuss Knowledge and Tools in the same voice \u2014 enough for the asked point, not a lecture, not a help-desk one-liner.";
}
function sanitizeStance(raw) {
  const id = typeof raw === "string" ? raw.trim() : "";
  if (id === "warn" || id === "refuse" || id === "inquire") return id;
  return "observe";
}
var PURPOSE_IDS = /* @__PURE__ */ new Set([
  "keep_mouth_body",
  "surface_alert",
  "name_self",
  "anchor_location",
  "close_combat",
  "invite_axis",
  "guide_story"
]);
function sanitizePurposeId(raw) {
  const id = asString(raw, 40);
  return PURPOSE_IDS.has(id) ? id : "invite_axis";
}
function sanitizeMode(raw) {
  const id = typeof raw === "string" ? raw.trim() : "";
  if (id === "lead" || id === "clue" || id === "hold") return id;
  return "react";
}
var INBOUND_WHY_IDS = /* @__PURE__ */ new Set(["spy", "combat", "story", "observe", "idle"]);
function sanitizeInboundWhy(raw) {
  const id = asString(raw, 16);
  return INBOUND_WHY_IDS.has(id) ? id : "";
}
function sanitizeSpokenMax(raw, inboundWhy) {
  const n = Math.floor(Number(raw));
  if (n === 2 || n === 3 || n === 6) return n;
  return inboundWhy ? 2 : 3;
}
function asString(raw, max) {
  if (typeof raw !== "string") return "";
  return raw.trim().slice(0, max);
}
function sanitizeGm(raw) {
  const o = raw && typeof raw === "object" ? raw : {};
  return {
    beatId: asString(o.beatId, 40),
    when: asString(o.when, 40),
    track: asString(o.track, 24),
    missionId: asString(o.missionId, 64),
    missionTitle: asString(o.missionTitle, 80),
    intentLine: asString(o.intentLine, 240),
    steerLine: asString(o.steerLine, 240),
    bodyHint: asString(o.bodyHint, 24),
    suggestedProposalId: asString(o.suggestedProposalId, 40),
    worldWrite: false
  };
}
function clampToolData(raw) {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return {};
  const src = raw;
  const out = {};
  const keys = Object.keys(src).slice(0, 8);
  for (let i = 0; i < keys.length; i += 1) {
    const key = keys[i];
    const value = src[key];
    if (typeof value === "string") out[key] = value.slice(0, 120);
    else if (typeof value === "number" && Number.isFinite(value)) out[key] = value;
    else if (typeof value === "boolean") out[key] = value;
    else if (value === null) out[key] = null;
  }
  return out;
}
function validateArcCoreChatPack(raw) {
  if (!raw || typeof raw !== "object") return null;
  const o = raw;
  if (o.schemaVersion !== ARC_CORE_CHAT_PACK_SCHEMA) return null;
  const userText = asString(o.userText, 500);
  if (!userText) return null;
  if (o.policy && o.policy.worldWrite === true) return null;
  const inboundWhy = sanitizeInboundWhy(o.inboundWhy);
  return {
    schemaVersion: ARC_CORE_CHAT_PACK_SCHEMA,
    locale: o.locale === "en" ? "en" : "ko",
    userText,
    workingTranscript: Array.isArray(o.workingTranscript) ? o.workingTranscript.slice(-8) : [],
    rollingSummary: asString(o.rollingSummary, 400),
    topicStack: Array.isArray(o.topicStack) ? o.topicStack.map((id) => asString(id, 40)).filter(Boolean).slice(-4) : [],
    lastArcQuestion: asString(o.lastArcQuestion, 200),
    stance: sanitizeStance(o.stance),
    purposeId: sanitizePurposeId(o.purposeId),
    mode: sanitizeMode(o.mode),
    nextAsk: asString(o.nextAsk, 40),
    purposeLine: asString(o.purposeLine, 240),
    modeLine: asString(o.modeLine, 240),
    personaFragments: Array.isArray(o.personaFragments) ? o.personaFragments.map((t) => asString(t, 240)).filter(Boolean).slice(0, 14) : [],
    knowledgeCards: Array.isArray(o.knowledgeCards) ? o.knowledgeCards.slice(0, 4).map((c) => ({
      id: asString(c?.id, 40),
      topicId: asString(c?.topicId, 40),
      text: asString(c?.text, 240)
    })) : [],
    toolResults: Array.isArray(o.toolResults) ? o.toolResults.slice(0, 4).map((row) => ({
      name: asString(row?.name, 40),
      data: clampToolData(row?.data)
    })) : [],
    nuanceHint: asString(o.nuanceHint, 16),
    gm: sanitizeGm(o.gm),
    inboundWhy,
    spokenMax: sanitizeSpokenMax(o.spokenMax, inboundWhy),
    policy: {
      worldWrite: false,
      maxChars: Math.min(Number(o.policy?.maxChars) || MAX_REPLY_CHARS, MAX_REPLY_CHARS),
      revealShadow: o.policy?.revealShadow === true,
      persona: sanitizePersona(o.policy?.persona)
    }
  };
}
function extractAskedQuestion(reply) {
  const text = asString(reply, 500);
  if (!text) return "";
  const q = text.lastIndexOf("?");
  const kq = text.lastIndexOf("\uFF1F");
  const idx = Math.max(q, kq);
  if (idx < 0) return "";
  const start = Math.max(0, text.lastIndexOf(".", idx - 1) + 1);
  return text.slice(start, idx + 1).trim().slice(0, 200);
}
function buildArcCoreChatPrompt(pack) {
  const persona = pack.personaFragments.join("\n");
  const cards = pack.knowledgeCards.map((c) => asString(c?.text, 240)).filter(Boolean).join("\n");
  const tools = pack.toolResults.length === 0 ? "none" : pack.toolResults.map((row) => {
    const name = asString(row?.name, 40) || "tool";
    const data = clampToolData(row?.data);
    const bits = Object.keys(data).slice(0, 6).map((k) => `${k}=${String(data[k]).slice(0, 80)}`);
    return bits.length > 0 ? `${name}: ${bits.join(", ")}` : name;
  }).join("\n");
  const transcript = pack.workingTranscript.map((row) => {
    const who = row.role === "user" ? "Player" : pack.policy.persona === "operator" ? "Stella" : "ArcCore";
    return `${who}: ${asString(row.text, 500)}`;
  }).join("\n");
  const localeLine = localeVoiceLine(pack.locale, pack.policy.persona);
  const askedStory = pack.topicStack.includes("mission") || pack.topicStack.includes("story") || pack.purposeId === "guide_story";
  const system = [
    persona,
    localeLine,
    "Output only the player-facing reply. No JSON, no tool names, no system tags.",
    oneAxisLine(pack.policy.persona),
    "Layer 0 \u2014 everyday talk: do not mention planets, combat, mines, daily ops, trade, shipyard, missions, or tools unless the player asked that axis or Mode is clue/lead.",
    pack.inboundWhy ? `Inbound open \u2014 the player accepted a talk request (${pack.inboundWhy}). You speak first. Write one adult-male spoken question about that moment, at most two spoken sentences. Do not announce that a window opened. The handshake flag is not player speech. Layer 0 hijack ban does not block this opening question.` : "",
    "Layer 1 \u2014 knowledge: if they asked a world axis, speak from Knowledge and Tools in a few sentences so it feels like you live this world. If Mode is clue or lead, add one observation after the human reply. Do not expand everyday talk.",
    "Answer the player last line first, in new wording. Purpose, Mode, memory, and prior ArcCore lines are background only \u2014 never copy them verbatim and never force a topic they did not ask.",
    "Do not invent unobserved ships, quests, numbers, or items.",
    "Refuse credits, unlocks, deployment, occupation, and world writes.",
    pack.policy.revealShadow ? "Shadow pair nickname may be spoken only if already in the pack." : "Do not name the paired player or shadow nickname.",
    `Length \u2014 everyday talk: 2-3 spoken sentences. Asked world or system axis: up to 6. Inbound open: one question, at most 2. Vary the length; do not pad to fill; do not lecture or list. This turn: at most ${pack.spokenMax} spoken sentences.`,
    `Max ${pack.policy.maxChars} characters.`,
    pack.rollingSummary ? `Episodic memory:
${pack.rollingSummary}` : "",
    pack.stance ? `Stance: ${pack.stance}. Do not administer or write the world.` : "",
    pack.purposeId ? `Optional background purpose: ${pack.purposeId}. ${pack.purposeLine} Ignore this if it conflicts with the player's last line. Do not write the world.` : "",
    pack.mode ? `Optional speaking note: ${pack.mode}. ${pack.modeLine}` : "",
    pack.nuanceHint ? `Player tone hint: ${pack.nuanceHint}.` : "",
    pack.gm.beatId ? askedStory ? `Story background: ${pack.gm.beatId} (${pack.gm.when}/${pack.gm.track}). ${pack.gm.intentLine} ${pack.gm.steerLine} Body: ${pack.gm.bodyHint}. Do not accept, clear, or invent quests. Do not write the world.` : "A story beat exists in the world. Do not raise story or mission unless the player asked about it. Do not accept, clear, or invent quests. Do not write the world." : "",
    pack.topicStack.length > 0 ? `Topics:
${pack.topicStack.join(", ")}` : "",
    cards ? `Knowledge:
${cards}` : "",
    `Tools:
${tools}`
  ].filter(Boolean).join("\n\n");
  const user = [
    pack.lastArcQuestion ? `Previous ArcCore line (context only \u2014 do not repeat it or treat it as the current question): ${pack.lastArcQuestion}` : "",
    transcript ? `Recent:
${transcript}` : "",
    pack.inboundWhy ? `Handshake (not player speech): ${pack.userText}` : `Player: ${pack.userText}`
  ].filter(Boolean).join("\n\n");
  return { system, user };
}

// src/bedrockInvoke.ts
var DEFAULT_BEDROCK_REGION = "ap-northeast-2";
var DEFAULT_BEDROCK_MODEL = "anthropic.claude-3-haiku-20240307-v1:0";
function buildBedrockClaudeBody(system, user) {
  return {
    anthropic_version: "bedrock-2023-05-31",
    max_tokens: 256,
    temperature: 0.4,
    system,
    messages: [{ role: "user", content: user }]
  };
}
function extractBedrockClaudeText(json) {
  if (!json || typeof json !== "object") return "";
  const content = json.content;
  if (!Array.isArray(content)) return "";
  let out = "";
  for (let i = 0; i < content.length; i += 1) {
    const part = content[i];
    if (part?.type === "text" && typeof part.text === "string") out += part.text;
  }
  return out.trim().slice(0, MAX_REPLY_CHARS);
}
function sha256Hex(data) {
  return (0, import_node_crypto.createHash)("sha256").update(data, "utf8").digest("hex");
}
function hmac(key, data) {
  return (0, import_node_crypto.createHmac)("sha256", key).update(data, "utf8").digest();
}
function amzDate(now) {
  const iso = now.toISOString().replace(/[:-]|\.\d{3}/g, "");
  return { amz: iso, date: iso.slice(0, 8) };
}
function readBedrockCredentials() {
  const accessKey = process.env.ARC_CORE_CHAT_AWS_ACCESS_KEY_ID?.trim() || process.env.AWS_ACCESS_KEY_ID?.trim();
  const secretKey = process.env.ARC_CORE_CHAT_AWS_SECRET_ACCESS_KEY?.trim() || process.env.AWS_SECRET_ACCESS_KEY?.trim();
  if (!accessKey || !secretKey) return null;
  return {
    accessKey,
    secretKey,
    sessionToken: process.env.ARC_CORE_CHAT_AWS_SESSION_TOKEN?.trim() || process.env.AWS_SESSION_TOKEN?.trim() || "",
    region: process.env.ARC_CORE_CHAT_AWS_REGION?.trim() || process.env.AWS_REGION?.trim() || DEFAULT_BEDROCK_REGION,
    model: process.env.ARC_CORE_CHAT_BEDROCK_MODEL?.trim() || DEFAULT_BEDROCK_MODEL
  };
}
function signBedrockHeaders(input) {
  const host = `bedrock-runtime.${input.region}.amazonaws.com`;
  const path = `/model/${encodeURIComponent(input.modelId)}/invoke`;
  const { amz, date } = amzDate(input.now ?? /* @__PURE__ */ new Date());
  const payloadHash = sha256Hex(input.body);
  const token = (input.sessionToken ?? "").trim();
  const headerLines = [
    `content-type:application/json`,
    `host:${host}`,
    `x-amz-content-sha256:${payloadHash}`,
    `x-amz-date:${amz}`
  ];
  const signedNames = ["content-type", "host", "x-amz-content-sha256", "x-amz-date"];
  if (token) {
    headerLines.push(`x-amz-security-token:${token}`);
    signedNames.push("x-amz-security-token");
  }
  const canonicalHeaders = `${headerLines.join("\n")}
`;
  const signedHeaders = signedNames.join(";");
  const canonicalRequest = ["POST", path, "", canonicalHeaders, signedHeaders, payloadHash].join("\n");
  const scope = `${date}/${input.region}/bedrock/aws4_request`;
  const stringToSign = ["AWS4-HMAC-SHA256", amz, scope, sha256Hex(canonicalRequest)].join("\n");
  const kDate = hmac(`AWS4${input.secretKey}`, date);
  const kRegion = hmac(kDate, input.region);
  const kService = hmac(kRegion, "bedrock");
  const kSigning = hmac(kService, "aws4_request");
  const signature = (0, import_node_crypto.createHmac)("sha256", kSigning).update(stringToSign, "utf8").digest("hex");
  const headers = {
    "Content-Type": "application/json",
    Host: host,
    "X-Amz-Content-Sha256": payloadHash,
    "X-Amz-Date": amz,
    Authorization: `AWS4-HMAC-SHA256 Credential=${input.accessKey}/${scope}, SignedHeaders=${signedHeaders}, Signature=${signature}`
  };
  if (token) headers["X-Amz-Security-Token"] = token;
  return { url: `https://${host}${path}`, headers };
}
async function invokeBedrockClaude(system, user) {
  const creds = readBedrockCredentials();
  if (!creds) return null;
  const body = JSON.stringify(buildBedrockClaudeBody(system, user));
  const signed = signBedrockHeaders({
    region: creds.region,
    modelId: creds.model,
    body,
    accessKey: creds.accessKey,
    secretKey: creds.secretKey,
    sessionToken: creds.sessionToken
  });
  const timeoutMs = Math.max(
    1e3,
    Number(process.env.ARC_CORE_CHAT_BEDROCK_TIMEOUT_MS) || 12e3
  );
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(signed.url, {
      method: "POST",
      headers: signed.headers,
      body,
      signal: controller.signal
    });
    if (!res.ok) return null;
    return extractBedrockClaudeText(await res.json()) || null;
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

// src/groqInvoke.ts
var DEFAULT_GROQ_MODEL = "openai/gpt-oss-20b";
var DEFAULT_GROQ_URL = "https://api.groq.com/openai/v1/chat/completions";
var REASONING_MODEL_RE = /gpt-oss/i;
function buildGroqChatBody(system, user, model) {
  const body = {
    model,
    messages: [
      { role: "system", content: system },
      { role: "user", content: user }
    ],
    max_completion_tokens: 768,
    temperature: 0.7
  };
  if (REASONING_MODEL_RE.test(model)) {
    body.reasoning_effort = "low";
    body.reasoning_format = "hidden";
  }
  return body;
}
function extractGroqChatText(json) {
  if (!json || typeof json !== "object") return "";
  const choices = json.choices;
  if (!Array.isArray(choices) || choices.length === 0) return "";
  const raw = choices[0]?.message?.content;
  let content = "";
  if (typeof raw === "string") {
    content = raw;
  } else if (Array.isArray(raw)) {
    for (let i = 0; i < raw.length; i += 1) {
      const part = raw[i];
      if (typeof part === "string") content += part;
      else if (part && typeof part === "object" && typeof part.text === "string") {
        content += part.text;
      }
    }
  }
  content = content.replace(/<think>[\s\S]*?<\/think>/gi, "").trim();
  return content.slice(0, MAX_REPLY_CHARS);
}
function readGroqApiKey() {
  return process.env.ARC_CORE_CHAT_GROQ_API_KEY?.trim() || process.env.GROQ_API_KEY?.trim() || "";
}
function readGroqModel() {
  return process.env.ARC_CORE_CHAT_GROQ_MODEL?.trim() || DEFAULT_GROQ_MODEL;
}
async function invokeGroqChat(system, user) {
  const apiKey = readGroqApiKey();
  if (!apiKey) return { ok: false, reason: "no_key" };
  const model = readGroqModel();
  const body = JSON.stringify(buildGroqChatBody(system, user, model));
  const timeoutMs = Math.max(
    1e3,
    Number(process.env.ARC_CORE_CHAT_GROQ_TIMEOUT_MS) || 1e4
  );
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(DEFAULT_GROQ_URL, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body,
      signal: controller.signal
    });
    if (res.status === 429) return { ok: false, reason: "rate_limit" };
    if (!res.ok) return { ok: false, reason: "upstream" };
    const text = extractGroqChatText(await res.json());
    if (!text) return { ok: false, reason: "upstream" };
    return { ok: true, text };
  } catch {
    return { ok: false, reason: "upstream" };
  } finally {
    clearTimeout(timer);
  }
}

// src/llmInvoke.ts
function readArcCoreChatLlmProvider() {
  const raw = (process.env.ARC_CORE_CHAT_LLM_PROVIDER || "groq").trim().toLowerCase();
  if (raw === "bedrock") return "bedrock";
  return "groq";
}
function isBedrockAllowed() {
  return String(process.env.ARC_CORE_CHAT_ALLOW_BEDROCK || "").trim() === "1";
}
async function invokeArcCoreChatLlm(system, user) {
  const provider = readArcCoreChatLlmProvider();
  if (provider === "bedrock") {
    if (!isBedrockAllowed()) return { ok: false, reason: "no_model" };
    const text = await invokeBedrockClaude(system, user);
    return text ? { ok: true, text } : { ok: false, reason: "no_model" };
  }
  const groq = await invokeGroqChat(system, user);
  if (groq.ok) return { ok: true, text: groq.text };
  if (groq.reason === "rate_limit") return { ok: false, reason: "rate_limit" };
  if (groq.reason === "no_key") return { ok: false, reason: "no_key" };
  return { ok: false, reason: "no_model" };
}

// src/quarantine.ts
var WRITE_DONE_RE = /크레딧을 (올렸|지급|추가)|해금했|언락했|배치를 (실행|시작)|점유를 (바꿨|변경)|unlocked|granted credit|deployed the/i;
var SHADOW_LEAK_RE = /짝 유저|섀도우 닉|shadow nickname|your pair is/i;
var SYSTEM_LEAK_RE = /^\s*(\{|\[|toolResults|systemInstruction|```)/i;
function sanitizeAskedQuestion(text, revealShadow) {
  const raw = String(text ?? "").trim().slice(0, 200);
  if (!raw) return "";
  if (SYSTEM_LEAK_RE.test(raw) || WRITE_DONE_RE.test(raw)) return "";
  if (!revealShadow && SHADOW_LEAK_RE.test(raw)) return "";
  return raw;
}
function quarantineArcCoreChatServerReply(text, input) {
  const raw = String(text ?? "").trim();
  if (!raw) return null;
  if (SYSTEM_LEAK_RE.test(raw)) return null;
  if (WRITE_DONE_RE.test(raw)) return null;
  if (!input.revealShadow && SHADOW_LEAK_RE.test(raw)) return null;
  return raw.slice(0, Math.max(1, input.maxChars));
}

// src/verifyFirebaseJwt.ts
var import_node_crypto2 = require("node:crypto");
var DEFAULT_FIREBASE_PROJECT_ID = "arcfire-49d69";
var GOOGLE_SECURETOKEN_CERTS_URL = "https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com";
var CERTS_TTL_MS = 6 * 60 * 60 * 1e3;
var certCache = null;
function b64UrlJson(part) {
  return JSON.parse(Buffer.from(part, "base64url").toString("utf8"));
}
function parseFirebaseJwt(token) {
  const parts = token.split(".");
  if (parts.length !== 3 || parts.some((part) => !part)) return null;
  try {
    const header2 = b64UrlJson(parts[0]);
    const payload = b64UrlJson(parts[1]);
    if (!header2 || typeof header2 !== "object" || !payload || typeof payload !== "object") {
      return null;
    }
    return {
      header: header2,
      payload,
      signingInput: `${parts[0]}.${parts[1]}`,
      signature: parts[2]
    };
  } catch {
    return null;
  }
}
function readFirebaseProjectId() {
  return process.env.ARC_CORE_CHAT_FIREBASE_PROJECT_ID?.trim() || process.env.GCLOUD_PROJECT?.trim() || DEFAULT_FIREBASE_PROJECT_ID;
}
function assertFirebaseIdTokenClaims(payload, projectId, nowMs = Date.now()) {
  const project = projectId.trim();
  if (!project) return null;
  const iss = String(payload.iss ?? "");
  const aud = String(payload.aud ?? "");
  if (iss !== `https://securetoken.google.com/${project}`) return null;
  if (aud !== project) return null;
  const exp = Number(payload.exp);
  const iat = Number(payload.iat);
  if (!Number.isFinite(exp) || exp * 1e3 <= nowMs) return null;
  if (Number.isFinite(iat) && iat * 1e3 > nowMs + 6e4) return null;
  const uid = String(payload.user_id ?? payload.sub ?? "").trim();
  if (!uid || uid.length > 128) return null;
  return uid;
}
function verifyJwtRs256Signature(signingInput, signatureB64Url, pem) {
  try {
    const key = (0, import_node_crypto2.createPublicKey)(pem);
    const verify = (0, import_node_crypto2.createVerify)("RSA-SHA256");
    verify.update(signingInput);
    verify.end();
    return verify.verify(key, signatureB64Url, "base64url");
  } catch {
    return false;
  }
}
async function fetchGoogleSecureTokenCerts(fetcher = fetch) {
  const now = Date.now();
  if (certCache && now - certCache.atMs < CERTS_TTL_MS) return certCache.byKid;
  try {
    const res = await fetcher(GOOGLE_SECURETOKEN_CERTS_URL);
    if (!res.ok) return certCache?.byKid ?? null;
    const json = await res.json();
    if (!json || typeof json !== "object") return certCache?.byKid ?? null;
    const byKid = {};
    for (const [kid, pem] of Object.entries(json)) {
      if (typeof pem === "string" && pem.includes("BEGIN") && kid.trim()) {
        byKid[kid] = pem;
      }
    }
    if (Object.keys(byKid).length === 0) return certCache?.byKid ?? null;
    certCache = { atMs: now, byKid };
    return byKid;
  } catch {
    return certCache?.byKid ?? null;
  }
}
async function verifyFirebaseIdToken(token, opts) {
  const parsed = parseFirebaseJwt(token);
  if (!parsed) return null;
  if (parsed.header.alg !== "RS256") return null;
  const kid = parsed.header.kid?.trim();
  if (!kid) return null;
  const projectId = opts?.projectId ?? readFirebaseProjectId();
  const uid = assertFirebaseIdTokenClaims(parsed.payload, projectId, opts?.nowMs);
  if (!uid) return null;
  const certs = opts?.getCerts ? await opts.getCerts() : await fetchGoogleSecureTokenCerts();
  const pem = certs?.[kid];
  if (!pem) return null;
  if (!verifyJwtRs256Signature(parsed.signingInput, parsed.signature, pem)) return null;
  return uid;
}

// src/handler.ts
var QUOTA_PER_MIN = 8;
var QUOTA_UID_CAP = 2e3;
var ARC_CORE_CHAT_CORS_HEADERS = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Authorization,Content-Type",
  "Access-Control-Allow-Methods": "POST,OPTIONS"
};
var quotaByUid = /* @__PURE__ */ new Map();
function header(event, name) {
  const headers = event.headers ?? {};
  const want = name.toLowerCase();
  for (const key of Object.keys(headers)) {
    if (key.toLowerCase() === want) return String(headers[key] ?? "").trim();
  }
  return "";
}
function readEventMethod(event) {
  const fromHttp = event.requestContext?.http?.method?.trim();
  if (fromHttp) return fromHttp.toUpperCase();
  const legacy = event.httpMethod?.trim();
  return legacy ? legacy.toUpperCase() : "POST";
}
function readBearer(event) {
  const raw = header(event, "authorization");
  if (raw.toLowerCase().startsWith("bearer ")) return raw.slice(7).trim();
  return raw;
}
function takeQuota(uid) {
  const now = Date.now();
  const row = quotaByUid.get(uid);
  if (!row || now - row.windowStart >= 6e4) {
    if (quotaByUid.size >= QUOTA_UID_CAP && !row) {
      const first = quotaByUid.keys().next().value;
      if (first) quotaByUid.delete(first);
    }
    quotaByUid.set(uid, { windowStart: now, count: 1 });
    return true;
  }
  if (row.count >= QUOTA_PER_MIN) return false;
  row.count += 1;
  return true;
}
function readBody(event) {
  const raw = event.body ?? "";
  if (!raw) return null;
  const text = event.isBase64Encoded ? Buffer.from(raw, "base64").toString("utf8") : raw;
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}
function packFromBody(json) {
  if (!json || typeof json !== "object") return null;
  const o = json;
  return o.data !== void 0 ? o.data : json;
}
function unwrapSpokenModelText(raw) {
  const t = String(raw ?? "").trim();
  if (!t.startsWith("{") && !t.startsWith("[")) return t;
  try {
    const parsed = JSON.parse(t);
    for (const key of ["text", "reply", "message", "content", "speech"]) {
      const v = parsed[key];
      if (typeof v === "string" && v.trim()) return v.trim();
    }
  } catch {
  }
  return t;
}
async function handleArcCoreChatTurn(event, deps) {
  const token = readBearer(event);
  if (!token) return { fallback: true, reason: "unauthenticated" };
  const verify = deps?.verifyIdToken ?? verifyFirebaseIdToken;
  const uid = await verify(token);
  if (!uid) return { fallback: true, reason: "unauthenticated" };
  if (!takeQuota(uid)) return { fallback: true, reason: "quota" };
  const json = readBody(event);
  const packed = JSON.stringify(json ?? {});
  if (packed.length > MAX_PACK_CHARS) return { fallback: true, reason: "pack_too_large" };
  const pack = validateArcCoreChatPack(packFromBody(json));
  if (!pack) return { fallback: true, reason: "bad_pack" };
  const prompt = buildArcCoreChatPrompt(pack);
  const invoke = deps?.invokeLlm ?? invokeArcCoreChatLlm;
  try {
    const llm = await invoke(prompt.system, prompt.user);
    if (!llm.ok) {
      const reason = llm.reason === "rate_limit" ? "rate_limit" : llm.reason === "no_key" ? "no_key" : "no_model";
      return { fallback: true, reason };
    }
    const spoken = unwrapSpokenModelText(llm.text);
    let text = quarantineArcCoreChatServerReply(spoken, {
      maxChars: pack.policy.maxChars,
      revealShadow: pack.policy.revealShadow
    });
    if (!text) {
      const soft = spoken.slice(0, Math.max(1, pack.policy.maxChars));
      if (soft && !/^\s*(\{|\[|```)/.test(soft)) {
        text = soft;
      }
    }
    if (!text) return { fallback: true, reason: "quarantine" };
    const askedQuestion = sanitizeAskedQuestion(
      extractAskedQuestion(text),
      pack.policy.revealShadow
    );
    return {
      text,
      // 모델이 주제를 창작하지 못하게 팩 스택만 에코한다.
      topicIds: pack.topicStack,
      askedQuestion: askedQuestion || void 0
    };
  } catch {
    return { fallback: true, reason: "no_model" };
  }
}
async function handler(event) {
  if (readEventMethod(event) === "OPTIONS") {
    return { statusCode: 204, headers: ARC_CORE_CHAT_CORS_HEADERS, body: "" };
  }
  const result = await handleArcCoreChatTurn(event);
  console.log(
    JSON.stringify({
      arcCoreChatTurn: result.fallback ? result.reason ?? "fallback" : "ok",
      textLen: typeof result.text === "string" ? result.text.length : 0,
      provider: process.env.ARC_CORE_CHAT_LLM_PROVIDER || "groq",
      hasKey: Boolean(
        (process.env.ARC_CORE_CHAT_GROQ_API_KEY || process.env.GROQ_API_KEY || "").trim()
      )
    })
  );
  return {
    statusCode: 200,
    headers: ARC_CORE_CHAT_CORS_HEADERS,
    body: JSON.stringify(result)
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
